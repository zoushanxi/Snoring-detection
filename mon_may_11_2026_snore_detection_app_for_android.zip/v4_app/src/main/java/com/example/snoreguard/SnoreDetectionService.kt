package com.example.snoreguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.util.Log
import java.io.File
import kotlin.math.max
import kotlin.math.min

class SnoreDetectionService : Service() {

    private var worker: Thread? = null
    @Volatile private var running = false

    override fun onCreate() {
        super.onCreate()
        startForeground(1001, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_STICKY
        running = true
        worker = Thread { loop() }.also { it.start() }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        worker?.join(1500)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification {
        val channelId = "snore_detection"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(channelId, "Snore Detection", NotificationManager.IMPORTANCE_LOW)
            )
        }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setContentTitle("SnoreGuard 正在检测")
                .setContentText("检测到打鼾会自动保存事件音频（m4a）")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("SnoreGuard 正在检测")
                .setContentText("检测到打鼾会自动保存事件音频（m4a）")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()
        }
    }

    private fun loop() {
        val sampleRate = 16000
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val channelCount = 1

        val minBuf = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
        val bufferSize = max(minBuf, sampleRate) // >= 1s
        val record = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            sampleRate,
            channelConfig,
            audioFormat,
            bufferSize
        )

        val dir = File(filesDir, "snore_events").apply { mkdirs() }

        val detector = Detector(sampleRate)
        val frameSize = 512
        val hopSize = 256
        val ring = DoubleArray(frameSize)
        var ringFill = 0

        val shortBuf = ShortArray(bufferSize / 2)
        val pcmBytes = ByteArray(shortBuf.size * 2)

        // pts（us）用采样累计
        var totalSamples: Long = 0

        // 自适应噪声底 + 能量门限
        var noiseFloor = 0.02
        val noiseAlpha = 0.995
        val margin = 0.015

        // 事件控制：开始后至少持续 minEventMs 才保留；结束后再写 tailMs 的音频
        val minEventMs = 800L
        val tailMs = 600L

        var snoreActive = false
        var eventStartSamples: Long = 0
        var tailEndSamples: Long = 0

        var encoder: AacM4aEncoder? = null
        var currentFile: File? = null

        fun startNewEventFile() {
            val f = File(dir, "event_${System.currentTimeMillis()}.m4a")
            currentFile = f
            encoder = AacM4aEncoder(f, sampleRate, channelCount, bitRate = 64000).also { it.start() }
            SnoreUiBus.update(UiState("保存事件中", 0.0, 0.0, true, f.absolutePath))
            Log.i("SnoreService", "Event file start: ${f.absolutePath}")
        }

        fun stopEventFile() {
            try { encoder?.stop() } catch (_: Exception) {}
            val f = currentFile
            encoder = null
            currentFile = null
            if (f != null) {
                SnoreUiBus.update(UiState("检测中", 0.0, 0.0, false, f.absolutePath))
                Log.i("SnoreService", "Event file done: ${f.absolutePath}")
            }
        }

        try {
            record.startRecording()
            SnoreUiBus.update(UiState("检测中", 0.0, 0.0, false, null))
            Log.i("SnoreService", "Recording started")

            while (running) {
                val nShorts = record.read(shortBuf, 0, shortBuf.size)
                if (nShorts <= 0) continue

                // shorts -> LE bytes（用于编码）
                var bi = 0
                for (i in 0 until nShorts) {
                    val s = shortBuf[i].toInt()
                    pcmBytes[bi++] = (s and 0xff).toByte()
                    pcmBytes[bi++] = ((s shr 8) and 0xff).toByte()
                }

                // 如果正在保存事件（snoreActive 或尾巴 tail），就把这段写进 encoder
                val samplesNowStart = totalSamples
                val samplesNowEnd = totalSamples + nShorts

                val shouldWrite =
                    (encoder != null) && (samplesNowStart < tailEndSamples)

                if (shouldWrite) {
                    val ptsUs = (samplesNowStart * 1_000_000L) / sampleRate
                    encoder!!.encode(pcmBytes, nShorts * 2, ptsUs)
                }

                // 检测分析（hop）
                var idx = 0
                while (idx < nShorts) {
                    val take = min(hopSize, nShorts - idx)
                    for (i in 0 until take) {
                        ring[ringFill] = shortBuf[idx + i] / 32768.0
                        ringFill++
                        if (ringFill >= frameSize) {
                            val res = detector.analyze(ring.copyOf())

                            noiseFloor = noiseAlpha * noiseFloor + (1 - noiseAlpha) * res.rms
                            val energyOk = res.rms > (noiseFloor + margin)
                            val snoreCandidate = energyOk && res.snoreLike

                            // 更新 UI（实时）
                            SnoreUiBus.update(
                                UiState(
                                    status = if (encoder != null) "保存事件中" else "检测中",
                                    rms = res.rms,
                                    lowBandRatio = res.lowRatio,
                                    isSnoreLike = snoreCandidate,
                                    currentFilePath = currentFile?.absolutePath
                                )
                            )

                            val nowSamples = totalSamples + idx.toLong()

                            if (snoreCandidate && !snoreActive) {
                                // 进入事件
                                snoreActive = true
                                eventStartSamples = nowSamples
                                tailEndSamples = Long.MAX_VALUE // 先占位
                                startNewEventFile()
                            }

                            if (!snoreCandidate && snoreActive) {
                                // 候选结束：进入尾巴写入
                                snoreActive = false

                                val durMs = ((nowSamples - eventStartSamples) * 1000L) / sampleRate
                                if (durMs < minEventMs) {
                                    // 太短：丢弃这个文件（最简单做法：停止并删除）
                                    val f = currentFile
                                    stopEventFile()
                                    if (f != null) f.delete()
                                    Log.i("SnoreService", "Discard short event ${durMs}ms")
                                } else {
                                    // 保留：设置 tail end
                                    tailEndSamples = nowSamples + (tailMs * sampleRate / 1000L)
                                    Log.i("SnoreService", "Event ended, tail until samples=$tailEndSamples")
                                }
                            }

                            // 如果已经不在事件中，并且尾巴也写完了，就关闭文件
                            if (!snoreActive && encoder != null && samplesNowEnd >= tailEndSamples) {
                                stopEventFile()
                                tailEndSamples = Long.MAX_VALUE
                            }

                            // hop move
                            val remain = frameSize - hopSize
                            for (j in 0 until remain) ring[j] = ring[j + hopSize]
                            ringFill = remain
                        }
                    }
                    idx += take
                }

                totalSamples += nShorts.toLong()
            }
        } catch (e: Exception) {
            Log.e("SnoreService", "Error", e)
            SnoreUiBus.update(UiState("异常：${e.message}", 0.0, 0.0, false, currentFile?.absolutePath))
        } finally {
            try { record.stop() } catch (_: Exception) {}
            record.release()
            try { encoder?.stop() } catch (_: Exception) {}
            SnoreUiBus.update(UiState("已停止", 0.0, 0.0, false, currentFile?.absolutePath))
            Log.i("SnoreService", "Recording stopped")
        }
    }
}
package com.example.snoreguard

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class UiState(
    val status: String,
    val rms: Double,
    val lowBandRatio: Double,
    val isSnoreLike: Boolean,
    val currentFilePath: String? = null
)

object SnoreUiBus {
    private val _state = MutableStateFlow(UiState("未开始", 0.0, 0.0, false, null))
    val state: StateFlow<UiState> = _state
    fun update(s: UiState) { _state.value = s }
}
package com.example.snoreguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.util.Log
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class SnoreDetectionService : Service() {

    private var worker: Thread? = null
    @Volatile private var running = false

    override fun onCreate() {
        super.onCreate()
        startForeground(1001, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_STICKY
        running = true
        worker = Thread { loop() }.also { it.start() }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        worker?.join(500)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification {
        val channelId = "snore_detection"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(channelId, "Snore Detection", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setContentTitle("SnoreGuard 正在检测")
                .setContentText("前台服务运行中")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("SnoreGuard 正在检测")
                .setContentText("前台服务运行中")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()
        }
    }

    private fun loop() {
        val sampleRate = 16000
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT

        val minBuf = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
        val bufferSize = max(minBuf, sampleRate) // 至少 1 秒缓冲
        val audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            sampleRate,
            channelConfig,
            audioFormat,
            bufferSize
        )

        val frameSize = 512  // FFT 大小（功耗与精度折中）
        val hopSize = 256

        val shortBuf = ShortArray(bufferSize / 2)
        val ring = DoubleArray(frameSize)
        var ringFill = 0

        // 自适应噪声底（简单指数滑动平均）
        var noiseFloor = 0.02
        val noiseAlpha = 0.995

        var snoreActive = false
        var snoreStartMs = 0L
        val minEventMs = 800L

        try {
            audioRecord.startRecording()
            Log.i("SnoreService", "Recording started")

            while (running) {
                val n = audioRecord.read(shortBuf, 0, shortBuf.size)
                if (n <= 0) continue

                // 分 hopSize 推入 ring，达到 frameSize 就分析一次
                var idx = 0
                while (idx < n) {
                    val take = min(hopSize, n - idx)
                    for (i in 0 until take) {
                        val v = shortBuf[idx + i] / 32768.0
                        ring[ringFill] = v
                        ringFill++
                        if (ringFill >= frameSize) {
                            analyzeFrame(
                                frame = ring.copyOf(),
                                sampleRate = sampleRate
                            ) { rms, lowRatio, isSnoreLike ->
                                // 更新噪声底（只在“非鼾声”时更新更稳，这里简化：始终慢更新）
                                noiseFloor = noiseAlpha * noiseFloor + (1 - noiseAlpha) * rms

                                // 动态阈值：噪声底 + margin
                                val margin = 0.015
                                val energyOk = rms > (noiseFloor + margin)

                                val snoreCandidate = energyOk && isSnoreLike

                                val now = System.currentTimeMillis()
                                if (snoreCandidate && !snoreActive) {
                                    snoreActive = true
                                    snoreStartMs = now
                                    Log.i("SnoreService", "SNORE START @ $snoreStartMs")
                                } else if (!snoreCandidate && snoreActive) {
                                    val dur = now - snoreStartMs
                                    snoreActive = false
                                    if (dur >= minEventMs) {
                                        Log.i("SnoreService", "SNORE END @ $now duration=${dur}ms")
                                    } else {
                                        Log.i("SnoreService", "Discard short event ${dur}ms")
                                    }
                                }

                                SnoreUiBus.post(
                                    Metrics(
                                        rms = rms,
                                        lowBandRatio = lowRatio,
                                        isSnoreLike = snoreCandidate
                                    )
                                )
                            }

                            // 帧移：保留后半段，实现 hop
                            // 简单实现：把后 frameSize-hopSize 段前移
                            val remain = frameSize - hopSize
                            for (j in 0 until remain) {
                                ring[j] = ring[j + hopSize]
                            }
                            ringFill = remain
                        }
                    }
                    idx += take
                }
            }
        } catch (e: Exception) {
            Log.e("SnoreService", "Error in loop", e)
        } finally {
            try {
                audioRecord.stop()
            } catch (_: Exception) {}
            audioRecord.release()
            Log.i("SnoreService", "Recording stopped")
        }
    }

    private fun analyzeFrame(
        frame: DoubleArray,
        sampleRate: Int,
        cb: (rms: Double, lowBandRatio: Double, isSnoreLike: Boolean) -> Unit
    ) {
        // 1) RMS
        var sum = 0.0
        for (v in frame) sum += v * v
        val rms = sqrt(sum / frame.size)

        // 2) FFT 幅度谱（简易 Cooley-Tukey：这里用最简“慢 FFT”会太慢）
        // 为了让示例可运行且代码不太长：使用 Goertzel-like 近似多个频点也可。
        // 这里实现一个“简化版频带能量”：用几个目标频点做能量估计（足够做 MVP 分类）。
        val targetsHz = intArrayOf(80, 120, 180, 240, 320, 400) // 打鼾常见低频区域
        val lowEnergy = targetsHz.sumOf { hz -> goertzelPower(frame, sampleRate, hz) }

        val highTargetsHz = intArrayOf(800, 1200, 2000, 3000)
        val highEnergy = highTargetsHz.sumOf { hz -> goertzelPower(frame, sampleRate, hz) }

        val total = lowEnergy + highEnergy + 1e-9
        val lowRatio = lowEnergy / total

        // 经验阈值：低频占比高 -> 更像鼾声（你需要在不同手机上调参）
        val isSnoreLike = lowRatio > 0.72

        cb(rms, lowRatio, isSnoreLike)
    }

    // Goertzel 算法估计某个频率的功率（比 FFT 轻量，适合少量频点）
    private fun goertzelPower(frame: DoubleArray, sampleRate: Int, targetHz: Int): Double {
        val n = frame.size
        val k = (0.5 + (n * targetHz.toDouble() / sampleRate)).toInt()
        val w = (2.0 * Math.PI * k) / n
        val cosine = kotlin.math.cos(w)
        val coeff = 2.0 * cosine

        var s0 = 0.0
        var s1 = 0.0
        var s2 = 0.0
        for (x in frame) {
            s0 = x + coeff * s1 - s2
            s2 = s1
            s1 = s0
        }
        val power = s1 * s1 + s2 * s2 - coeff * s1 * s2
        return max(0.0, power)
    }
}
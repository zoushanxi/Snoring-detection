package com.example.snoreguard

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

data class Metrics(
    val rms: Double,
    val lowBandRatio: Double,
    val isSnoreLike: Boolean
)

object SnoreUiBus {
    private val _metrics = MutableLiveData(Metrics(0.0, 0.0, false))
    val metrics: LiveData<Metrics> = _metrics

    fun post(m: Metrics) {
        _metrics.postValue(m)
    }
}
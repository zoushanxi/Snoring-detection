package com.example.snoreguard

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

class AudioWavWriter(
    private val file: File,
    private val sampleRate: Int,
    private val channels: Int = 1,
    private val bitsPerSample: Int = 16
) {
    private var raf: RandomAccessFile? = null
    private var dataBytesWritten: Long = 0

    fun start() {
        file.parentFile?.mkdirs()
        raf = RandomAccessFile(file, "rw")
        raf!!.setLength(0)
        writeHeaderPlaceholder()
    }

    fun writePcm16LE(buffer: ShortArray, count: Int) {
        val r = raf ?: return
        val bb = ByteBuffer.allocate(count * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until count) bb.putShort(buffer[i])
        r.write(bb.array())
        dataBytesWritten += (count * 2).toLong()
    }

    fun stop() {
        val r = raf ?: return
        // 回填 header
        r.seek(0)
        writeHeader(
            r,
            dataSize = dataBytesWritten,
            sampleRate = sampleRate,
            channels = channels,
            bitsPerSample = bitsPerSample
        )
        r.close()
        raf = null
    }

    private fun writeHeaderPlaceholder() {
        val r = raf ?: return
        // 44 bytes WAV header
        r.write(ByteArray(44))
    }

    private fun writeHeader(
        r: RandomAccessFile,
        dataSize: Long,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int
    ) {
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val blockAlign = channels * bitsPerSample / 8
        val chunkSize = 36 + dataSize

        fun putString(s: String) = r.writeBytes(s)
        fun putIntLE(v: Int) {
            r.write(byteArrayOf(
                (v and 0xff).toByte(),
                ((v shr 8) and 0xff).toByte(),
                ((v shr 16) and 0xff).toByte(),
                ((v shr 24) and 0xff).toByte(),
            ))
        }
        fun putShortLE(v: Short) {
            r.write(byteArrayOf(
                (v.toInt() and 0xff).toByte(),
                ((v.toInt() shr 8) and 0xff).toByte()
            ))
        }

        putString("RIFF")
        putIntLE(chunkSize.toInt())
        putString("WAVE")

        putString("fmt ")
        putIntLE(16) // PCM
        putShortLE(1) // AudioFormat PCM
        putShortLE(channels.toShort())
        putIntLE(sampleRate)
        putIntLE(byteRate)
        putShortLE(blockAlign.toShort())
        putShortLE(bitsPerSample.toShort())

        putString("data")
        putIntLE(dataSize.toInt())
    }
}
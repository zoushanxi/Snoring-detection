package com.example.snoreguard

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer

class AacM4aEncoder(
    private val outFile: File,
    private val sampleRate: Int,
    private val channelCount: Int,
    private val bitRate: Int = 64000
) {
    private var codec: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var trackIndex: Int = -1
    private var muxerStarted = false

    private val bufferInfo = MediaCodec.BufferInfo()

    fun start() {
        outFile.parentFile?.mkdirs()
        if (outFile.exists()) outFile.delete()

        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channelCount).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }

        codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC).apply {
            configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            start()
        }

        muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        trackIndex = -1
        muxerStarted = false
    }

    fun encodePcm16(pcm: ByteArray, length: Int, presentationTimeUs: Long) {
        val c = codec ?: return

        // input
        val inIndex = c.dequeueInputBuffer(10_000)
        if (inIndex >= 0) {
            val inBuf = c.getInputBuffer(inIndex)!!
            inBuf.clear()
            inBuf.put(pcm, 0, length)
            c.queueInputBuffer(inIndex, 0, length, presentationTimeUs, 0)
        }

        drain()
    }

    fun stop() {
        val c = codec
        if (c != null) {
            val inIndex = c.dequeueInputBuffer(10_000)
            if (inIndex >= 0) {
                c.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            }
            drain(finalDrain = true)
        }

        try { codec?.stop() } catch (_: Exception) {}
        try { codec?.release() } catch (_: Exception) {}
        codec = null

        try {
            if (muxerStarted) muxer?.stop()
        } catch (_: Exception) {}
        try { muxer?.release() } catch (_: Exception) {}
        muxer = null
    }

    private fun drain(finalDrain: Boolean = false) {
        val c = codec ?: return
        val m = muxer ?: return

        while (true) {
            val outIndex = c.dequeueOutputBuffer(bufferInfo, 10_000)
            when {
                outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!finalDrain) return
                    // final drain: keep looping a bit; but if nothing, break
                    return
                }
                outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (muxerStarted) throw IllegalStateException("format changed twice")
                    val newFormat = c.outputFormat
                    trackIndex = m.addTrack(newFormat)
                    m.start()
                    muxerStarted = true
                }
                outIndex >= 0 -> {
                    val outBuf: ByteBuffer = c.getOutputBuffer(outIndex)!!
                    if (bufferInfo.size > 0) {
                        if (!muxerStarted) {
                            // 理论上 INFO_OUTPUT_FORMAT_CHANGED 应该先来
                            throw IllegalStateException("Muxer hasn't started")
                        }
                        outBuf.position(bufferInfo.offset)
                        outBuf.limit(bufferInfo.offset + bufferInfo.size)
                        m.writeSampleData(trackIndex, outBuf, bufferInfo)
                    }
                    c.releaseOutputBuffer(outIndex, false)

                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        return
                    }
                }
            }
        }
    }
}
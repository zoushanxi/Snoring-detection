package com.example.snoreguard

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvMetrics: TextView

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            tvStatus.text = if (granted) "权限已授予，可以开始检测" else "未授予录音权限，无法检测"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvMetrics = findViewById(R.id.tvMetrics)

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            ensureAudioPermissionThenStart()
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, SnoreDetectionService::class.java))
            tvStatus.text = "状态：已停止"
        }

        // 接收服务广播（简单演示用；正式可改成 Flow/LiveData/BoundService）
        SnoreUiBus.metrics.observe(this) { m ->
            tvMetrics.text = "RMS: %.2f  LowBandRatio: %.2f".format(m.rms, m.lowBandRatio)
            tvStatus.text = "状态：" + if (m.isSnoreLike) "疑似打鼾" else "安静/非鼾声"
        }
    }

    private fun ensureAudioPermissionThenStart() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        if (!granted) {
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }

        val intent = Intent(this, SnoreDetectionService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ContextCompat.startForegroundService(this, intent)
        } else {
            startService(intent)
        }
        tvStatus.text = "状态：启动中..."
    }
}
package com.example.snoreguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.util.Log
import java.io.File
import kotlin.math.max
import kotlin.math.min

class SnoreDetectionService : Service() {

    private var worker: Thread? = null
    @Volatile private var running = false

    override fun onCreate() {
        super.onCreate()
        startForeground(1001, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_STICKY
        running = true
        worker = Thread { loop() }.also { it.start() }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        worker?.join(1200)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification {
        val channelId = "snore_detection"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(channelId, "Snore Detection", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setContentTitle("SnoreGuard 正在检测")
                .setContentText("录音分析中（AAC 保存到私有目录）")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("SnoreGuard 正在检测")
                .setContentText("录音分析中（AAC 保存到私有目录）")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()
        }
    }

    private fun loop() {
        val sampleRate = 16000
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val channelCount = 1

        val minBuf = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
        val bufferSize = max(minBuf, sampleRate) // >= 1s
        val audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            sampleRate,
            channelConfig,
            audioFormat,
            bufferSize
        )

        val dir = File(filesDir, "snore_aac")
        val outFile = File(dir, "snore_${System.currentTimeMillis()}.m4a")
        val encoder = AacM4aEncoder(outFile, sampleRate, channelCount, bitRate = 64000)

        val detector = Detector(sampleRate)
        val frameSize = 512
        val hopSize = 256
        val ring = DoubleArray(frameSize)
        var ringFill = 0

        var noiseFloor = 0.02
        val noiseAlpha = 0.995
        val margin = 0.015

        val shortBuf = ShortArray(bufferSize / 2)
        val pcmBytes = ByteArray(shortBuf.size * 2)

        // 用音频样本累计计算 pts（microseconds）
        var totalSamples: Long = 0

        try {
            encoder.start()
            audioRecord.startRecording()
            SnoreUiBus.update(SnoreState("检测中", 0.0, 0.0, false, outFile.absolutePath))
            Log.i("SnoreService", "Start -> ${outFile.absolutePath}")

            while (running) {
                val nShorts = audioRecord.read(shortBuf, 0, shortBuf.size)
                if (nShorts <= 0) continue

                // shorts -> little endian bytes
                var bi = 0
                for (i in 0 until nShorts) {
                    val s = shortBuf[i].toInt()
                    pcmBytes[bi++] = (s and 0xff).toByte()
                    pcmBytes[bi++] = ((s shr 8) and 0xff).toByte()
                }

                val ptsUs = (totalSamples * 1_000_000L) / sampleRate
                encoder.encodePcm16(pcmBytes, nShorts * 2, ptsUs)
                totalSamples += nShorts.toLong()

                // 检测：push ring
                var idx = 0
                while (idx < nShorts) {
                    val take = min(hopSize, nShorts - idx)
                    for (i in 0 until take) {
                        ring[ringFill] = shortBuf[idx + i] / 32768.0
                        ringFill++
                        if (ringFill >= frameSize) {
                            val frame = ring.copyOf()
                            val res = detector.analyze(frame)

                            noiseFloor = noiseAlpha * noiseFloor + (1 - noiseAlpha) * res.rms
                            val energyOk = res.rms > (noiseFloor + margin)
                            val snoreCandidate = energyOk && res.snoreLike

                            SnoreUiBus.update(
                                SnoreState(
                                    status = "检测中",
                                    rms = res.rms,
                                    lowBandRatio = res.lowBandRatio,
                                    isSnoreLike = snoreCandidate,
                                    currentAudioFile = outFile.absolutePath
                                )
                            )

                            // hop move
                            val remain = frameSize - hopSize
                            for (j in 0 until remain) ring[j] = ring[j + hopSize]
                            ringFill = remain
                        }
                    }
                    idx += take
                }
            }
        } catch (e: Exception) {
            Log.e("SnoreService", "Error", e)
            SnoreUiBus.update(SnoreState("异常：${e.message}", 0.0, 0.0, false, outFile.absolutePath))
        } finally {
            try { audioRecord.stop() } catch (_: Exception) {}
            audioRecord.release()
            try { encoder.stop() } catch (_: Exception) {}
            SnoreUiBus.update(SnoreState("已停止", 0.0, 0.0, false, outFile.absolutePath))
            Log.i("SnoreService", "Stopped. Saved: ${outFile.absolutePath}")
        }
    }
}
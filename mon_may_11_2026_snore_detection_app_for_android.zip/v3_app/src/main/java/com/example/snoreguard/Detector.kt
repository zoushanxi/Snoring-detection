package com.example.snoreguard

import kotlin.math.max
import kotlin.math.sqrt

data class DetectorOut(val rms: Double, val lowRatio: Double, val snoreLike: Boolean)

class Detector(private val sampleRate: Int) {

    fun analyze(frame: DoubleArray): DetectorOut {
        var sum = 0.0
        for (v in frame) sum += v * v
        val rms = sqrt(sum / frame.size)

        val lowTargets = intArrayOf(80, 120, 180, 240, 320, 400)
        val highTargets = intArrayOf(800, 1200, 2000, 3000)

        val lowE = lowTargets.sumOf { goertzel(frame, sampleRate, it) }
        val highE = highTargets.sumOf { goertzel(frame, sampleRate, it) }
        val total = lowE + highE + 1e-9
        val lowRatio = lowE / total

        // 经验阈值：低频占比较高 + 能量门限（能量门限在 Service 里做自适应）
        val snoreLike = lowRatio > 0.72
        return DetectorOut(rms, lowRatio, snoreLike)
    }

    private fun goertzel(frame: DoubleArray, sampleRate: Int, targetHz: Int): Double {
        val n = frame.size
        val k = (0.5 + (n * targetHz.toDouble() / sampleRate)).toInt()
        val w = (2.0 * Math.PI * k) / n
        val coeff = 2.0 * kotlin.math.cos(w)

        var s0 = 0.0
        var s1 = 0.0
        var s2 = 0.0
        for (x in frame) {
            s0 = x + coeff * s1 - s2
            s2 = s1
            s1 = s0
        }
        val power = s1 * s1 + s2 * s2 - coeff * s1 * s2
        return max(0.0, power)
    }
}
package com.example.snoreguard

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {

    private val reqAudio = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val reqNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            reqNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            MaterialTheme {
                Home(
                    onStart = {
                        reqAudio.launch(Manifest.permission.RECORD_AUDIO)
                        ContextCompat.startForegroundService(
                            this,
                            Intent(this, SnoreDetectionService::class.java)
                        )
                    },
                    onStop = { stopService(Intent(this, SnoreDetectionService::class.java)) }
                )
            }
        }
    }
}

@Composable
private fun Home(onStart: () -> Unit, onStop: () -> Unit) {
    var status by remember { mutableStateOf("未开始") }
    var rms by remember { mutableStateOf(0.0) }
    var lowRatio by remember { mutableStateOf(0.0) }
    var isSnore by remember { mutableStateOf(false) }
    var currentFile by remember { mutableStateOf("-") }

    LaunchedEffect(Unit) {
        SnoreUiBus.state.collectLatest { s ->
            status = s.status
            rms = s.rms
            lowRatio = s.lowBandRatio
            isSnore = s.isSnoreLike
            currentFile = s.currentAudioFile ?: "-"
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("状态：$status", style = MaterialTheme.typography.titleMedium)
        Text("RMS: ${"%.4f".format(rms)}  LowBandRatio: ${"%.3f".format(lowRatio)}")
        Text("疑似打鼾：${if (isSnore) "是" else "否"}")
        Text("当前音频文件：$currentFile", style = MaterialTheme.typography.bodySmall)

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onStart) { Text("开始检测") }
            OutlinedButton(onClick = onStop) { Text("停止") }
        }

        Text(
            "音频将保存为 AAC(.m4a) 到应用私有目录 files/snore_aac/ 下（卸载会清除）。",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
package com.example.snoreguard

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class SnoreState(
    val status: String,
    val rms: Double,
    val lowBandRatio: Double,
    val isSnoreLike: Boolean,
    val currentAudioFile: String? = null
)

object SnoreUiBus {
    private val _state = MutableStateFlow(SnoreState("未开始", 0.0, 0.0, false, null))
    val state: StateFlow<SnoreState> = _state

    fun update(s: SnoreState) {
        _state.value = s
    }
}
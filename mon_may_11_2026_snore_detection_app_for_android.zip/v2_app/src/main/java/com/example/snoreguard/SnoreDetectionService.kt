package com.example.snoreguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.util.Log
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class SnoreDetectionService : Service() {

    private var worker: Thread? = null
    @Volatile private var running = false

    override fun onCreate() {
        super.onCreate()
        startForeground(1001, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_STICKY
        running = true
        worker = Thread { recordLoop() }.also { it.start() }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        worker?.join(800)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification {
        val channelId = "snore_detection"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(channelId, "Snore Detection", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setContentTitle("SnoreGuard 正在检测")
                .setContentText("录音分析中（音频本地保存）")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("SnoreGuard 正在检测")
                .setContentText("录音分析中（音频本地保存）")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()
        }
    }

    private fun recordLoop() {
        val sampleRate = 16000
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT

        val minBuf = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
        val bufferSize = max(minBuf, sampleRate) // >= 1s
        val audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            sampleRate,
            channelConfig,
            audioFormat,
            bufferSize
        )

        val dir = File(filesDir, "snore_wav")
        val file = File(dir, "snore_${System.currentTimeMillis()}.wav")
        val wavWriter = AudioWavWriter(file, sampleRate = sampleRate)

        val detector = Detector(sampleRate)

        val shortBuf = ShortArray(bufferSize / 2)

        val frameSize = 512
        val hopSize = 256
        val ring = DoubleArray(frameSize)
        var ringFill = 0

        var noiseFloor = 0.02
        val noiseAlpha = 0.995
        val margin = 0.015

        var snoreActive = false
        var snoreStartMs = 0L
        val minEventMs = 800L

        try {
            wavWriter.start()
            audioRecord.startRecording()

            SnoreUiBus.update(SnoreState("检测中", 0.0, 0.0, false, file.absolutePath))
            Log.i("SnoreService", "Recording started -> ${file.absolutePath}")

            while (running) {
                val n = audioRecord.read(shortBuf, 0, shortBuf.size)
                if (n <= 0) continue

                // 1) 保存音频
                wavWriter.writePcm16LE(shortBuf, n)

                // 2) 推入 ring，按 hop 分析
                var idx = 0
                while (idx < n) {
                    val take = min(hopSize, n - idx)
                    for (i in 0 until take) {
                        ring[ringFill] = shortBuf[idx + i] / 32768.0
                        ringFill++
                        if (ringFill >= frameSize) {
                            val frame = ring.copyOf()
                            val res = detector.analyzeFrame(frame)

                            noiseFloor = noiseAlpha * noiseFloor + (1 - noiseAlpha) * res.rms
                            val energyOk = res.rms > (noiseFloor + margin)

                            val snoreCandidate = energyOk && res.snoreLike

                            val now = System.currentTimeMillis()
                            if (snoreCandidate && !snoreActive) {
                                snoreActive = true
                                snoreStartMs = now
                                Log.i("SnoreService", "SNORE START @ $snoreStartMs")
                            } else if (!snoreCandidate && snoreActive) {
                                val dur = now - snoreStartMs
                                snoreActive = false
                                if (dur >= minEventMs) {
                                    Log.i("SnoreService", "SNORE END @ $now duration=${dur}ms")
                                    // TODO: 这里写入事件元数据（JSON/Room）
                                }
                            }

                            SnoreUiBus.update(
                                SnoreState(
                                    status = "检测中",
                                    rms = res.rms,
                                    lowBandRatio = res.lowBandRatio,
                                    isSnoreLike = snoreCandidate,
                                    currentWavFile = file.absolutePath
                                )
                            )

                            // hop 移动
                            val remain = frameSize - hopSize
                            for (j in 0 until remain) ring[j] = ring[j + hopSize]
                            ringFill = remain
                        }
                    }
                    idx += take
                }
            }
        } catch (e: Exception) {
            Log.e("SnoreService", "Error", e)
            SnoreUiBus.update(SnoreState("异常：${e.message}", 0.0, 0.0, false, file.absolutePath))
        } finally {
            try { audioRecord.stop() } catch (_: Exception) {}
            audioRecord.release()
            try { wavWriter.stop() } catch (_: Exception) {}
            SnoreUiBus.update(SnoreState("已停止", 0.0, 0.0, false, file.absolutePath))
            Log.i("SnoreService", "Stopped. WAV saved: ${file.absolutePath}")
        }
    }
}
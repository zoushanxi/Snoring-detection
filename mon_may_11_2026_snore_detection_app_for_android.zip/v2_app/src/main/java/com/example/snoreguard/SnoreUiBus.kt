package com.example.snoreguard

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class SnoreState(
    val status: String,
    val rms: Double,
    val lowBandRatio: Double,
    val isSnoreLike: Boolean,
    val currentWavFile: String? = null
)

object SnoreUiBus {
    private val _state = MutableStateFlow(
        SnoreState(status = "未开始", rms = 0.0, lowBandRatio = 0.0, isSnoreLike = false)
    )
    val state: StateFlow<SnoreState> = _state

    fun update(s: SnoreState) {
        _state.value = s
    }
}
package com.example.snoreguard

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer

class AacM4aEncoder(
    private val outFile: File,
    private val sampleRate: Int,
    private val channelCount: Int,
    private val bitRate: Int = 64000
) {
    private var codec: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var trackIndex = -1
    private var muxerStarted = false
    private val bufferInfo = MediaCodec.BufferInfo()

    fun start() {
        outFile.parentFile?.mkdirs()
        if (outFile.exists()) outFile.delete()

        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channelCount).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }

        codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC).apply {
            configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            start()
        }

        muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        trackIndex = -1
        muxerStarted = false
    }

    fun encode(pcmLE: ByteArray, len: Int, ptsUs: Long) {
        val c = codec ?: return
        val inIndex = c.dequeueInputBuffer(10_000)
        if (inIndex >= 0) {
            val inBuf = c.getInputBuffer(inIndex)!!
            inBuf.clear()
            inBuf.put(pcmLE, 0, len)
            c.queueInputBuffer(inIndex, 0, len, ptsUs, 0)
        }
        drain(finalDrain = false)
    }

    fun stop() {
        val c = codec
        if (c != null) {
            val inIndex = c.dequeueInputBuffer(10_000)
            if (inIndex >= 0) {
                c.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            }
            drain(finalDrain = true)
        }

        try { codec?.stop() } catch (_: Exception) {}
        try { codec?.release() } catch (_: Exception) {}
        codec = null

        try { if (muxerStarted) muxer?.stop() } catch (_: Exception) {}
        try { muxer?.release() } catch (_: Exception) {}
        muxer = null
    }

    private fun drain(finalDrain: Boolean) {
        val c = codec ?: return
        val m = muxer ?: return

        while (true) {
            val outIndex = c.dequeueOutputBuffer(bufferInfo, 10_000)
            when {
                outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> return
                outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (muxerStarted) throw IllegalStateException("format changed twice")
                    trackIndex = m.addTrack(c.outputFormat)
                    m.start()
                    muxerStarted = true
                }
                outIndex >= 0 -> {
                    val outBuf: ByteBuffer = c.getOutputBuffer(outIndex)!!
                    if (bufferInfo.size > 0) {
                        if (!muxerStarted) throw IllegalStateException("muxer not started")
                        outBuf.position(bufferInfo.offset)
                        outBuf.limit(bufferInfo.offset + bufferInfo.size)
                        m.writeSampleData(trackIndex, outBuf, bufferInfo)
                    }
                    c.releaseOutputBuffer(outIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
            if (!finalDrain) {
                // 非最终 drain：不要死循环占用 CPU
                // 这里靠下一次 encode 再进 drain
                // 所以出一次样本就跳出也可以，但保持简单：继续由 INFO_TRY_AGAIN_LATER 退出
            }
        }
    }
}